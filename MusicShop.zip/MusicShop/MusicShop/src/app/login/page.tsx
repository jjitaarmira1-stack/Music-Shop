"use client";

import { Suspense, useState, type FormEvent } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import { AudioWaveform, KeyRound, Loader2, UserRoundPlus } from "lucide-react";
import { toast } from "sonner";
import { useSession } from "@/lib/session";
import { cn } from "@/lib/utils";
import { BUSINESS } from "@/lib/business";
import Aurora from "@/components/bits/Aurora";
import SplitText from "@/components/bits/SplitText";
import StarBorder from "@/components/bits/StarBorder";
import SpotlightCard from "@/components/bits/SpotlightCard";

function LoginForm() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [pending, setPending] = useState(false);
  const router = useRouter();
  const searchParams = useSearchParams();
  const { refresh } = useSession();

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setPending(true);
    try {
      const endpoint = mode === "login" ? "/api/auth/login" : "/api/auth/register";
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error ?? "Algo salió mal");
        return;
      }
      await refresh();
      toast.success(
        mode === "login"
          ? `De nuevo en el escenario, ${data.user.name.split(" ")[0]}`
          : "Cuenta creada: bienvenido al atelier",
      );
      const next = searchParams.get("next");
      router.push(next ?? (data.user.role === "admin" ? "/admin" : "/cuenta"));
      router.refresh();
    } catch {
      toast.error("No se pudo conectar con el servidor");
    } finally {
      setPending(false);
    }
  };

  return (
    <div className="relative flex min-h-svh items-center justify-center overflow-hidden px-5 py-28">
      <Aurora />
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="relative w-full max-w-md"
      >
        <SpotlightCard className="glass rounded-3xl p-8 md:p-10">
          <div className="mx-auto mb-6 grid h-14 w-14 place-items-center rounded-full border border-ember/40 bg-ember/10 text-ember">
            <AudioWaveform className="h-6 w-6" />
          </div>
          <h1 className="text-center font-display text-4xl">
            <SplitText
              text={mode === "login" ? "Vuelve al escenario" : "Únete al atelier"}
              key={mode}
            />
          </h1>
          <p className="mt-2 text-center text-sm text-fog">
            {mode === "login"
              ? "Accede con tu cuenta del atelier"
              : "Crea tu cuenta en menos de un compás"}
          </p>
          <p className="mt-1 text-center font-display text-sm italic text-ember/80">
            {BUSINESS.name} {BUSINESS.suffix}
          </p>

          <div className="mt-8 grid grid-cols-2 rounded-full border border-line p-1">
            {(["login", "register"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={cn(
                  "relative rounded-full py-2.5 text-sm transition-colors",
                  mode === m ? "text-ink" : "text-fog hover:text-cream",
                )}
              >
                {mode === m && (
                  <motion.span
                    layoutId="auth-tab"
                    className="absolute inset-0 rounded-full bg-ember"
                  />
                )}
                <span className="relative z-10">
                  {m === "login" ? "Entrar" : "Crear cuenta"}
                </span>
              </button>
            ))}
          </div>

          <form onSubmit={onSubmit} className="mt-8 space-y-4">
            {mode === "register" && (
              <div>
                <label className="mb-2 block font-mono text-[10px] uppercase tracking-[0.25em] text-fog">
                  Nombre
                </label>
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  placeholder="María Mercury"
                  className="w-full rounded-2xl border border-line bg-panel/60 px-5 py-3.5 text-sm text-cream outline-none transition-colors placeholder:text-fog/60 focus:border-ember/60"
                />
              </div>
            )}
            <div>
              <label className="mb-2 block font-mono text-[10px] uppercase tracking-[0.25em] text-fog">
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                placeholder="tú@ejemplo.com"
                className="w-full rounded-2xl border border-line bg-panel/60 px-5 py-3.5 text-sm text-cream outline-none transition-colors placeholder:text-fog/60 focus:border-ember/60"
              />
            </div>
            <div>
              <label className="mb-2 block font-mono text-[10px] uppercase tracking-[0.25em] text-fog">
                Contraseña
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                placeholder="••••••••••"
                className="w-full rounded-2xl border border-line bg-panel/60 px-5 py-3.5 text-sm text-cream outline-none transition-colors placeholder:text-fog/60 focus:border-ember/60"
              />
            </div>
            <div className="pt-2">
              <StarBorder
                type="submit"
                disabled={pending}
                className="w-full"
                innerClassName="w-full py-4 disabled:opacity-60"
              >
                {pending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : mode === "login" ? (
                  <KeyRound className="h-4 w-4" />
                ) : (
                  <UserRoundPlus className="h-4 w-4" />
                )}
                {mode === "login" ? "Entrar al atelier" : "Crear mi cuenta"}
              </StarBorder>
            </div>
          </form>
        </SpotlightCard>

        <div className="mt-6 rounded-2xl border border-line bg-coal/70 px-6 py-4 text-center">
          <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-fog">
            Credenciales demo
          </p>
          <p className="mt-2 font-mono text-xs leading-relaxed text-cream/70">
            {BUSINESS.demoAccounts.map((a) => (
              <span key={a.email} className="block">
                {a.email} / {a.password}
              </span>
            ))}
          </p>
        </div>
      </motion.div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  );
}
