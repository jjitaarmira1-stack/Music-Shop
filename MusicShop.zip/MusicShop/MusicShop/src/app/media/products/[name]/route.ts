import { NextResponse } from "next/server";
import { promises as fs } from "node:fs";
import path from "node:path";

const MIME: Record<string, string> = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
  ".avif": "image/avif",
};

/**
 * Sirve al vuelo las imágenes subidas desde la galería del admin.
 * Los estáticos congelados en el build siguen yendo por `/img/...`, pero
 * en producción (`next start`) un archivo nuevo solo existe en disco:
 * esta ruta lo encuentra y lo re-expone como `/media/products/<name>`.
 */
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ name: string }> },
) {
  try {
    const { name } = await params;
    if (!/^[A-Za-z0-9._-]+$/.test(name)) {
      return NextResponse.json({ error: "Nombre no válido" }, { status: 400 });
    }
    const ext = path.extname(name).toLowerCase();
    const type = MIME[ext];
    if (!type) {
      return NextResponse.json({ error: "Formato no admitido" }, { status: 400 });
    }

    const file = path.join(process.cwd(), "public", "img", "products", name);
    const data = await fs.readFile(file);
    return new Response(new Uint8Array(data), {
      headers: {
        "Content-Type": type,
        "Cache-Control": "public, max-age=31536000, immutable",
      },
    });
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") {
      return NextResponse.json({ error: "No encontrada" }, { status: 404 });
    }
    console.error("[media/products/GET]", error);
    return NextResponse.json({ error: "Error interno" }, { status: 500 });
  }
}
