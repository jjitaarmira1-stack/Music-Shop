import { NextResponse } from "next/server";
import { findUserByEmail } from "@/lib/data";
import { setSessionCookie, verifyPassword } from "@/lib/auth";

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json();
    if (!email || !password) {
      return NextResponse.json(
        { error: "Email y contraseña son obligatorios" },
        { status: 400 },
      );
    }

    const user = await findUserByEmail(String(email));
    if (!user || !verifyPassword(String(password), user.passwordHash)) {
      return NextResponse.json(
        { error: "Credenciales incorrectas" },
        { status: 401 },
      );
    }

    const session = {
      uid: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
    };
    await setSessionCookie(session);
    return NextResponse.json({ user: session });
  } catch (error) {
    console.error("[auth/login]", error);
    return NextResponse.json({ error: "Error interno" }, { status: 500 });
  }
}
