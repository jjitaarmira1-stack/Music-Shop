import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { findUserByEmail } from "@/lib/data";
import { hashPassword, setSessionCookie } from "@/lib/auth";

export async function POST(request: Request) {
  try {
    const { name, email, password } = await request.json();
    if (!name || !email || !password) {
      return NextResponse.json(
        { error: "Todos los campos son obligatorios" },
        { status: 400 },
      );
    }
    if (String(password).length < 6) {
      return NextResponse.json(
        { error: "La contraseña debe tener al menos 6 caracteres" },
        { status: 400 },
      );
    }

    const normalized = String(email).toLowerCase().trim();
    const existing = await findUserByEmail(normalized);
    if (existing) {
      return NextResponse.json(
        { error: "Ya existe una cuenta con este email" },
        { status: 409 },
      );
    }

    const [user] = await db
      .insert(users)
      .values({
        name: String(name).trim(),
        email: normalized,
        passwordHash: hashPassword(String(password)),
        role: "customer",
      })
      .returning();

    const session = {
      uid: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
    };
    await setSessionCookie(session);
    return NextResponse.json({ user: session }, { status: 201 });
  } catch (error) {
    console.error("[auth/register]", error);
    return NextResponse.json({ error: "Error interno" }, { status: 500 });
  }
}
