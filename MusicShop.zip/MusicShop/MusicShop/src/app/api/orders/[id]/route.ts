import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, type OrderStatus } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { eq } from "drizzle-orm";

const VALID: OrderStatus[] = [
  "pendiente",
  "pagado",
  "enviado",
  "entregado",
  "cancelado",
];

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await getSession();
  if (session?.role !== "admin") {
    return NextResponse.json({ error: "No autorizado" }, { status: 403 });
  }
  try {
    const { id } = await params;
    const { status } = await request.json();
    if (!VALID.includes(status)) {
      return NextResponse.json({ error: "Estado inválido" }, { status: 400 });
    }
    const [order] = await db
      .update(orders)
      .set({ status })
      .where(eq(orders.id, id))
      .returning();
    if (!order) {
      return NextResponse.json({ error: "No encontrado" }, { status: 404 });
    }
    return NextResponse.json({ order });
  } catch (error) {
    console.error("[orders/PATCH]", error);
    return NextResponse.json({ error: "Error interno" }, { status: 500 });
  }
}
