import { NextResponse } from "next/server";
import crypto from "node:crypto";
import { db } from "@/db";
import { orders, products, type OrderItem } from "@/db/schema";
import { getAllOrders, getOrdersForUser } from "@/lib/data";
import { getSession } from "@/lib/auth";
import { BUSINESS } from "@/lib/business";
import { eq, sql } from "drizzle-orm";

export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  }
  try {
    const list =
      session.role === "admin"
        ? await getAllOrders()
        : await getOrdersForUser(session.uid);
    return NextResponse.json({ orders: list });
  } catch (error) {
    console.error("[orders/GET]", error);
    return NextResponse.json({ error: "Error interno" }, { status: 500 });
  }
}

interface CartLine {
  productId: string;
  qty: number;
}

export async function POST(request: Request) {
  try {
    const session = await getSession();
    const body = await request.json();
    const { customerName, customerEmail, address } = body;
    const lines: CartLine[] = Array.isArray(body.items) ? body.items : [];

    if (!customerName || !customerEmail || !address) {
      return NextResponse.json(
        { error: "Nombre, email y dirección son obligatorios" },
        { status: 400 },
      );
    }
    if (lines.length === 0) {
      return NextResponse.json(
        { error: "El carrito está vacío" },
        { status: 400 },
      );
    }

    // Recalcular precios en servidor: nunca confiar en el cliente.
    const order = await db.transaction(async (tx) => {
      const items: OrderItem[] = [];
      let totalCents = 0;

      for (const line of lines) {
        const qty = Math.max(1, Math.round(Number(line.qty) || 1));
        const [product] = await tx
          .select()
          .from(products)
          .where(eq(products.id, String(line.productId)))
          .limit(1);
        if (!product) {
          throw new OrderError(`Producto no encontrado: ${line.productId}`);
        }
        if (product.stock < qty) {
          throw new OrderError(
            `Stock insuficiente para ${product.name} (quedan ${product.stock})`,
          );
        }
        items.push({
          productId: product.id,
          slug: product.slug,
          name: product.name,
          priceCents: product.priceCents,
          qty,
          image: product.image,
        });
        totalCents += product.priceCents * qty;
      }

      for (const item of items) {
        await tx
          .update(products)
          .set({ stock: sql`${products.stock} - ${item.qty}` })
          .where(eq(products.id, item.productId));
      }

      const code = `${BUSINESS.orderPrefix}-${new Date().getFullYear()}-${crypto
        .randomBytes(3)
        .toString("hex")
        .toUpperCase()}`;

      const [created] = await tx
        .insert(orders)
        .values({
          code,
          userId: session?.uid ?? null,
          customerName: String(customerName).trim(),
          customerEmail: String(customerEmail).toLowerCase().trim(),
          address: String(address).trim(),
          items,
          totalCents,
          status: "pagado",
        })
        .returning();
      return created;
    });

    return NextResponse.json({ order }, { status: 201 });
  } catch (error) {
    if (error instanceof OrderError) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }
    console.error("[orders/POST]", error);
    return NextResponse.json({ error: "Error interno" }, { status: 500 });
  }
}

class OrderError extends Error {}
