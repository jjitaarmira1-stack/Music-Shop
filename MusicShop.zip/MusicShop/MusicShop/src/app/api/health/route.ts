import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { BUSINESS } from "@/lib/business";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    return NextResponse.json({
      status: "ok",
      db: "up",
      app: BUSINESS.name.toLowerCase(),
    });
  } catch {
    return NextResponse.json(
      { status: "degraded", db: "down", app: BUSINESS.name.toLowerCase() },
      { status: 503 },
    );
  }
}
