import { NextResponse } from "next/server";
import { db } from "@/db";
import { products, type NewProduct } from "@/db/schema";
import { getProducts } from "@/lib/data";
import { getSession } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const list = await getProducts({
      category: searchParams.get("category") ?? undefined,
      q: searchParams.get("q") ?? undefined,
      ...(searchParams.get("featured") === "1" ? { featured: true } : {}),
    });
    return NextResponse.json({ products: list });
  } catch (error) {
    console.error("[products/GET]", error);
    return NextResponse.json({ error: "Error interno" }, { status: 500 });
  }
}

function slugify(name: string) {
  return name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export async function POST(request: Request) {
  const session = await getSession();
  if (session?.role !== "admin") {
    return NextResponse.json({ error: "No autorizado" }, { status: 403 });
  }
  try {
    const body = await request.json();
    const required = ["name", "tagline", "description", "category", "priceCents"];
    for (const field of required) {
      if (body[field] === undefined || body[field] === "") {
        return NextResponse.json(
          { error: `El campo ${field} es obligatorio` },
          { status: 400 },
        );
      }
    }

    const base = slugify(String(body.name)) || "instrumento";
    const slug = `${base}-${Math.random().toString(36).slice(2, 6)}`;

    const payload: NewProduct = {
      slug,
      name: String(body.name).trim(),
      tagline: String(body.tagline).trim(),
      description: String(body.description).trim(),
      category: String(body.category),
      priceCents: Math.max(0, Math.round(Number(body.priceCents))),
      stock: Math.max(0, Math.round(Number(body.stock ?? 0))),
      image: body.image || "/img/products/guitarra-electrica.jpg",
      featured: Boolean(body.featured),
      specs: Array.isArray(body.specs) ? body.specs : [],
    };

    const [product] = await db.insert(products).values(payload).returning();
    return NextResponse.json({ product }, { status: 201 });
  } catch (error) {
    console.error("[products/POST]", error);
    return NextResponse.json({ error: "Error interno" }, { status: 500 });
  }
}
