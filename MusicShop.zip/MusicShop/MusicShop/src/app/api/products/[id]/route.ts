import { NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { eq } from "drizzle-orm";

type Params = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: Params) {
  const session = await getSession();
  if (session?.role !== "admin") {
    return NextResponse.json({ error: "No autorizado" }, { status: 403 });
  }
  try {
    const { id } = await params;
    const body = await request.json();
    const patch: Record<string, unknown> = {};
    for (const key of [
      "name",
      "tagline",
      "description",
      "category",
      "image",
    ]) {
      if (body[key] !== undefined) patch[key] = String(body[key]);
    }
    if (body.priceCents !== undefined)
      patch.priceCents = Math.max(0, Math.round(Number(body.priceCents)));
    if (body.stock !== undefined)
      patch.stock = Math.max(0, Math.round(Number(body.stock)));
    if (body.featured !== undefined) patch.featured = Boolean(body.featured);
    if (body.specs !== undefined)
      patch.specs = Array.isArray(body.specs) ? body.specs : [];

    const [product] = await db
      .update(products)
      .set(patch)
      .where(eq(products.id, id))
      .returning();
    if (!product) {
      return NextResponse.json({ error: "No encontrado" }, { status: 404 });
    }
    return NextResponse.json({ product });
  } catch (error) {
    console.error("[products/PATCH]", error);
    return NextResponse.json({ error: "Error interno" }, { status: 500 });
  }
}

export async function DELETE(_request: Request, { params }: Params) {
  const session = await getSession();
  if (session?.role !== "admin") {
    return NextResponse.json({ error: "No autorizado" }, { status: 403 });
  }
  try {
    const { id } = await params;
    await db.delete(products).where(eq(products.id, id));
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("[products/DELETE]", error);
    return NextResponse.json({ error: "Error interno" }, { status: 500 });
  }
}
