import { NextResponse } from "next/server";
import { promises as fs } from "node:fs";
import path from "node:path";
import { getSession } from "@/lib/auth";

const ROOT = path.join(process.cwd(), "public", "img");
const PRODUCTS_DIR = path.join(ROOT, "products");
const ALLOWED_EXTS = [".jpg", ".jpeg", ".png", ".webp", ".avif"];
const MAX_BYTES = 6 * 1024 * 1024; // 6 MB

export interface UploadedImage {
  name: string;
  path: string; // ruta web /img/...
  folder: string;
  sizeKb: number;
}

// ─── Lista la librería de imágenes (solo admin) ─────────────────────────────

export async function GET() {
  const session = await getSession();
  if (session?.role !== "admin") {
    return NextResponse.json({ error: "No autorizado" }, { status: 403 });
  }
  try {
    const images: UploadedImage[] = [];

    async function scan(dir: string, webPrefix: string, folder: string) {
      let entries;
      try {
        entries = await fs.readdir(dir, { withFileTypes: true });
      } catch {
        return; // la carpeta aún no existe
      }
      for (const entry of entries) {
        if (!entry.isFile()) continue;
        if (!ALLOWED_EXTS.includes(path.extname(entry.name).toLowerCase()))
          continue;
        const stat = await fs.stat(path.join(dir, entry.name));
        images.push({
          name: entry.name,
          path: `${webPrefix}${entry.name}`,
          folder,
          sizeKb: Math.max(1, Math.ceil(stat.size / 1024)),
        });
      }
    }

    await scan(PRODUCTS_DIR, "/img/products/", "products");
    await scan(ROOT, "/img/", "raíz");

    images.sort((a, b) => a.path.localeCompare(b.path));
    return NextResponse.json({ images });
  } catch (error) {
    console.error("[uploads/GET]", error);
    return NextResponse.json({ error: "Error interno" }, { status: 500 });
  }
}

// ─── Sube una imagen a public/img/products/ (solo admin) ───────────────────

function safeBaseName(name: string) {
  const base = name.replace(/\.[^.]+$/, "");
  return (
    base
      .toLowerCase()
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "")
      .slice(0, 60) || "imagen"
  );
}

export async function POST(request: Request) {
  const session = await getSession();
  if (session?.role !== "admin") {
    return NextResponse.json({ error: "No autorizado" }, { status: 403 });
  }
  try {
    const formData = await request.formData();
    const file = formData.get("file");
    if (!(file instanceof File)) {
      return NextResponse.json(
        { error: "Adjunta el archivo en el campo «file»" },
        { status: 400 },
      );
    }

    const ext = path.extname(file.name).toLowerCase();
    if (!ALLOWED_EXTS.includes(ext)) {
      return NextResponse.json(
        { error: "Formato no admitido (usa jpg, png, webp o avif)" },
        { status: 400 },
      );
    }
    if (file.size > MAX_BYTES) {
      return NextResponse.json(
        { error: "La imagen supera los 6 MB" },
        { status: 400 },
      );
    }

    const name = `${Date.now().toString(36)}-${safeBaseName(file.name)}${ext}`;
    const buffer = Buffer.from(await file.arrayBuffer());
    await fs.mkdir(PRODUCTS_DIR, { recursive: true });
    await fs.writeFile(path.join(PRODUCTS_DIR, name), buffer);

    return NextResponse.json({ name, path: `/img/products/${name}` }, { status: 201 });
  } catch (error) {
    console.error("[uploads/POST]", error);
    return NextResponse.json({ error: "Error interno" }, { status: 500 });
  }
}
