import { NextResponse } from "next/server";
import { promises as fs } from "node:fs";
import path from "node:path";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { products } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { getSession } from "@/lib/auth";

// ─── Borra una imagen si ningún instrumento la referencia (solo admin) ──────

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ name: string }> },
) {
  const session = await getSession();
  if (session?.role !== "admin") {
    return NextResponse.json({ error: "No autorizado" }, { status: 403 });
  }
  try {
    const { name } = await params;
    if (!/^[A-Za-z0-9._-]+$/.test(name)) {
      return NextResponse.json({ error: "Nombre no válido" }, { status: 400 });
    }

    const webPath = `/img/products/${name}`;
    await ensureSeeded();
    const [reference] = await db
      .select({ id: products.id })
      .from(products)
      .where(eq(products.image, webPath))
      .limit(1);
    if (reference) {
      return NextResponse.json(
        {
          error:
            "No se puede borrar: un instrumento del catálogo usa esta imagen",
        },
        { status: 409 },
      );
    }

    const file = path.join(process.cwd(), "public", "img", "products", name);
    await fs.unlink(file);
    return NextResponse.json({ ok: true });
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === "ENOENT") {
      return NextResponse.json({ error: "Imagen no encontrada" }, { status: 404 });
    }
    console.error("[uploads/DELETE]", error);
    return NextResponse.json({ error: "Error interno" }, { status: 500 });
  }
}
