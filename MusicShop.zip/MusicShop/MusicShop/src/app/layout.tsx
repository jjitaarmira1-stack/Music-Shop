import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Instrument_Serif, Space_Grotesk, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import Providers from "@/components/site/Providers";
import Navbar from "@/components/site/Navbar";
import Footer from "@/components/site/Footer";
import CartDrawer from "@/components/site/CartDrawer";
import Cursor from "@/components/bits/Cursor";
import { BUSINESS } from "@/lib/business";

const instrument = Instrument_Serif({
  subsets: ["latin"],
  weight: ["400"],
  style: ["normal", "italic"],
  variable: "--font-instrument",
});

const grotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-grotesk",
});

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-jetbrains",
});

export const metadata: Metadata = {
  title: {
    default: `${BUSINESS.name.toUpperCase()} — ${BUSINESS.tagline}`,
    template: `%s · ${BUSINESS.name.toUpperCase()}`,
  },
  description: BUSINESS.description,
};

export const viewport: Viewport = {
  themeColor: "#0b0a08",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="es"
      className={`${instrument.variable} ${grotesk.variable} ${jetbrains.variable}`}
    >
      <body className="grain bg-ink text-cream antialiased selection:bg-ember selection:text-ink">
        <Providers>
          <Cursor />
          <Navbar />
          <CartDrawer />
          <main>{children}</main>
          <Footer />
        </Providers>
      </body>
    </html>
  );
}
