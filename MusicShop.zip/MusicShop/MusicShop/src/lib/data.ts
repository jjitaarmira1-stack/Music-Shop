import { db } from "@/db";
import { ensureSeeded } from "@/db/seed";
import { orders, products, users } from "@/db/schema";
import { and, count, desc, eq, ilike, ne, sql, type SQL } from "drizzle-orm";

// ─── Productos ──────────────────────────────────────────────────────────────

export interface ProductFilters {
  category?: string;
  q?: string;
  featured?: boolean;
}

export async function getProducts(filters: ProductFilters = {}) {
  await ensureSeeded();
  const clauses: SQL[] = [];
  if (filters.category && filters.category !== "todos") {
    clauses.push(eq(products.category, filters.category));
  }
  if (filters.q) {
    const needle = `%${filters.q.trim()}%`;
    clauses.push(ilike(products.name, needle));
  }
  if (filters.featured) clauses.push(eq(products.featured, true));

  return db
    .select()
    .from(products)
    .where(clauses.length ? and(...clauses) : undefined)
    .orderBy(desc(products.featured), products.name);
}

export async function getProductBySlug(slug: string) {
  await ensureSeeded();
  const [product] = await db
    .select()
    .from(products)
    .where(eq(products.slug, slug))
    .limit(1);
  return product ?? null;
}

export async function getRelatedProducts(slug: string, category: string) {
  await ensureSeeded();
  return db
    .select()
    .from(products)
    .where(and(eq(products.category, category), ne(products.slug, slug)))
    .limit(3);
}

// ─── Autenticación ──────────────────────────────────────────────────────────

export async function findUserByEmail(email: string) {
  await ensureSeeded();
  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.email, email.toLowerCase().trim()))
    .limit(1);
  return user ?? null;
}

// ─── Pedidos ────────────────────────────────────────────────────────────────

export async function getAllOrders() {
  await ensureSeeded();
  return db.select().from(orders).orderBy(desc(orders.createdAt));
}

export async function getOrdersForUser(userId: string) {
  await ensureSeeded();
  return db
    .select()
    .from(orders)
    .where(eq(orders.userId, userId))
    .orderBy(desc(orders.createdAt));
}

// ─── Estadísticas (panel admin) ─────────────────────────────────────────────

export async function getAdminStats() {
  await ensureSeeded();
  const [[productsRow], [ordersRow], [usersRow], [revenueRow], recent] =
    await Promise.all([
      db.select({ value: count() }).from(products),
      db.select({ value: count() }).from(orders),
      db.select({ value: count() }).from(users),
      db
        .select({
          value: sql<number>`coalesce(sum(${orders.totalCents}), 0)::int`,
        })
        .from(orders)
        .where(ne(orders.status, "cancelado")),
      db.select().from(orders).orderBy(desc(orders.createdAt)).limit(5),
    ]);

  return {
    totalProducts: productsRow.value,
    totalOrders: ordersRow.value,
    totalCustomers: usersRow.value,
    revenueCents: revenueRow.value,
    recentOrders: recent,
  };
}
