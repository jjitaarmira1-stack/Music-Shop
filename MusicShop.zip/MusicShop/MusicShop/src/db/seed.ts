import { db } from "@/db";
import { users, products, type NewProduct, type Role } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { BUSINESS } from "@/lib/business";
import { sql } from "drizzle-orm";

// Las cuentas demo se definen en src/lib/business.ts (editables por el dueño).
export const DEMO_CREDENTIALS: Array<{
  name: string;
  email: string;
  password: string;
  role: Role;
}> = BUSINESS.demoAccounts.map((a) => ({
  name: a.name,
  email: a.email,
  password: a.password,
  role: a.role,
}));

const SEED_PRODUCTS: NewProduct[] = [
  {
    slug: "noir-vantage",
    name: "Noir Vantage",
    tagline: "Guitarra eléctrica de autor",
    description:
      "Cuerpo de caoba maciza con acabado satinado negro absoluto. Pastillas humbucker de bobinado manual, diapasón de ébano y un sustain que parece no terminar nunca. Construida para escenarios donde la luz apenas existe.",
    category: "cuerdas",
    priceCents: 249900,
    stock: 7,
    image: "/img/products/guitarra-electrica.jpg",
    featured: true,
    specs: [
      { label: "Cuerpo", value: "Caoba maciza" },
      { label: "Mástil", value: "Arce tostado" },
      { label: "Pastillas", value: "2× Humbucker boutique" },
      { label: "Acabado", value: "Negro satinado" },
    ],
  },
  {
    slug: "atlas-folk",
    name: "Atlas Folk",
    tagline: "Guitarra acústica de nogal",
    description:
      "Tapa de pícea maciza y aros de nogal americano. Voz cálida, profunda y con una proyección que llena la habitación sin esfuerzo. Cada unidad se ajusta a mano durante seis horas antes de salir del taller.",
    category: "cuerdas",
    priceCents: 118900,
    stock: 12,
    image: "/img/products/guitarra-acustica.jpg",
    featured: false,
    specs: [
      { label: "Tapa", value: "Pícea maciza" },
      { label: "Aros y fondo", value: "Nogal americano" },
      { label: "Escala", value: "645 mm" },
      { label: "Incluye", value: "Estuche rígido" },
    ],
  },
  {
    slug: "pulse-a88",
    name: "Pulse A-88",
    tagline: "Sintetizador analógico",
    description:
      "Cuatro osciladores de voltaje real, filtro ladder de 24 dB y una matriz de modulación sin menús: todo está bajo tus dedos. El bruto analógico que define una época, con la estabilidad que exige un estudio moderno.",
    category: "teclas",
    priceCents: 184900,
    stock: 5,
    image: "/img/products/sintetizador.jpg",
    featured: true,
    specs: [
      { label: "Osciladores", value: "4× VCO" },
      { label: "Filtro", value: "Ladder 24 dB/oct" },
      { label: "Teclas", value: "61 semi-contrapesadas" },
      { label: "Secuenciador", value: "64 pasos" },
    ],
  },
  {
    slug: "tundra-kit",
    name: "Tundra Kit",
    tagline: "Batería acústica 5 cuerpos",
    description:
      "Cascos de abedul báltico de 7 láminas y herrajes macizos. Bombo de 22″ con pegada seca, timbales que cantan y platillos de bronce B20 martilleados a mano. Lista para girar desde la primera caja.",
    category: "percusion",
    priceCents: 209900,
    stock: 4,
    image: "/img/products/bateria.jpg",
    featured: false,
    specs: [
      { label: "Cascos", value: "Abedul 7 láminas" },
      { label: "Bombo", value: "22″ × 18″" },
      { label: "Platillos", value: "Bronce B20" },
      { label: "Herrajes", value: "Doble refuerzo" },
    ],
  },
  {
    slug: "vela-44",
    name: "Vela 4/4",
    tagline: "Violín de concierto",
    description:
      "Arce flameado de bosques centenarios y barniz al aceite aplicado en doce capas. Un instrumento de proyección noble y armónicos cristalinos, graduado a mano por un único lutier de principio a fin.",
    category: "cuerdas",
    priceCents: 345000,
    stock: 3,
    image: "/img/products/violin.jpg",
    featured: true,
    specs: [
      { label: "Fondo", value: "Arce flameado" },
      { label: "Tapa", value: "Pícea de abeto Val di Fiemme" },
      { label: "Barniz", value: "Aceite, 12 capas" },
      { label: "Cuerdas", value: "Entorchado sintético" },
    ],
  },
  {
    slug: "bruma-alto",
    name: "Bruma Alto",
    tagline: "Saxofón alto en Mi♭",
    description:
      "Latón dorado con grabado artesanal y llaves de tacto nacarado. Registro grave aterciopelado, agudos que cortan sin estridencia. Afinación revisada instrumento a instrumento por nuestro atelier de viento.",
    category: "viento",
    priceCents: 167500,
    stock: 6,
    image: "/img/products/saxofon.jpg",
    featured: true,
    specs: [
      { label: "Cuerpo", value: "Latón dorado" },
      { label: "Tono", value: "Mi bemol" },
      { label: "Llaves", value: "Hasta Fa♯ agudo" },
      { label: "Boquilla", value: "Ebonita tallada a mano" },
    ],
  },
  {
    slug: "orbe-jazz",
    name: "Orbe Jazz",
    tagline: "Bajo eléctrico de precisión",
    description:
      "Grave redondo, definido y siempre en su sitio. Cuerpo de aliso, mástil slim de perfil C y electrónica activa de 3 bandas para esculpir desde dub hasta fusión sin tocar el ampli.",
    category: "cuerdas",
    priceCents: 132000,
    stock: 9,
    image: "/img/products/bajo.jpg",
    featured: false,
    specs: [
      { label: "Cuerpo", value: "Aliso" },
      { label: "Trastes", value: "21 medium-jumbo" },
      { label: "Electrónica", value: "Activa 3 bandas" },
      { label: "Escala", value: "34″" },
    ],
  },
  {
    slug: "lumen-m1",
    name: "Lumen M-1",
    tagline: "Micrófono de condensador",
    description:
      "Cápsula de gran diafragma con baño de oro y electrónica discreta clase A. Capta el aire entre las notas: voces íntimas, guitarras con cuerpo y room drums con una sola toma.",
    category: "estudio",
    priceCents: 48900,
    stock: 15,
    image: "/img/products/microfono.jpg",
    featured: false,
    specs: [
      { label: "Cápsula", value: "34 mm baño de oro" },
      { label: "Patrón", value: "Cardioide" },
      { label: "Circuito", value: "Clase A discreta" },
      { label: "Incluye", value: "Suspensión antishock" },
    ],
  },
];

let seedPromise: Promise<void> | null = null;

/** Idempotente: siembra usuarios demo y catálogo solo si la base está vacía. */
export function ensureSeeded(): Promise<void> {
  seedPromise ??= (async () => {
    try {
      const [{ value: userCount }] = await db
        .select({ value: sql<number>`count(*)::int` })
        .from(users);
      if (userCount === 0) {
        await db.insert(users).values(
          DEMO_CREDENTIALS.map(({ name, email, password, role }) => ({
            name,
            email,
            role,
            passwordHash: hashPassword(password),
          })),
        );
        console.log("[nocturne] usuarios demo sembrados");
      }

      const [{ value: productCount }] = await db
        .select({ value: sql<number>`count(*)::int` })
        .from(products);
      if (productCount === 0) {
        await db.insert(products).values(SEED_PRODUCTS);
        console.log("[nocturne] catálogo sembrado");
      }
    } catch (error) {
      seedPromise = null; // permitir reintento si la DB aún no estaba lista
      console.error("[nocturne] seed falló:", error);
    }
  })();
  return seedPromise;
}
