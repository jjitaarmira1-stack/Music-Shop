"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Check,
  CloudUpload,
  Copy,
  Images,
  Loader2,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export interface GalleryImage {
  name: string;
  path: string;
  folder: string;
  sizeKb: number;
}

/** Librería visual de imágenes: sube, previsualiza, copia rutas y limpia. */
export default function GalleryManager({
  onChange,
}: {
  onChange?: (paths: string[]) => void;
}) {
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(0);
  const [dragging, setDragging] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [deleting, setDeleting] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/uploads", { cache: "no-store" });
      const data = await res.json();
      if (res.ok) {
        const list: GalleryImage[] = data.images ?? [];
        setImages(list);
        onChange?.(list.map((i) => i.path));
      }
    } catch {
      toast.error("No se pudo cargar la galería");
    } finally {
      setLoading(false);
    }
  }, [onChange]);

  useEffect(() => {
    void load();
  }, [load]);

  const uploadFiles = async (files: Iterable<File>) => {
    const list = Array.from(files);
    if (list.length === 0) return;
    setUploading(list.length);
    let ok = 0;
    for (const file of list) {
      try {
        const formData = new FormData();
        formData.append("file", file);
        const res = await fetch("/api/uploads", {
          method: "POST",
          body: formData,
        });
        const data = await res.json();
        if (res.ok) ok += 1;
        else toast.error(data.error ?? `Error con ${file.name}`);
      } catch {
        toast.error(`Error de red con ${file.name}`);
      }
    }
    setUploading(0);
    if (ok > 0) {
      toast.success(
        ok === 1 ? "Imagen publicada en la galería" : `${ok} imágenes publicadas`,
      );
      await load();
    }
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    void uploadFiles(e.dataTransfer.files);
  };

  const copyPath = async (imagePath: string) => {
    try {
      await navigator.clipboard.writeText(imagePath);
      setCopied(imagePath);
      toast.success("Ruta copiada", { description: imagePath });
      setTimeout(() => setCopied(null), 1600);
    } catch {
      toast.info("Ruta de la imagen", { description: imagePath });
    }
  };

  const removeImage = async (image: GalleryImage) => {
    if (!window.confirm(`¿Borrar «${image.name}» de la galería?`)) return;
    setDeleting(image.name);
    try {
      const res = await fetch(
        `/api/uploads/${encodeURIComponent(image.name)}`,
        { method: "DELETE" },
      );
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error ?? "No se pudo borrar");
      } else {
        toast.success("Imagen retirada");
        await load();
      }
    } finally {
      setDeleting(null);
    }
  };

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h2 className="flex items-baseline gap-3 font-display text-2xl">
          Galería
          <span className="font-mono text-sm text-fog">{images.length}</span>
        </h2>
        <button
          onClick={() => inputRef.current?.click()}
          className="flex items-center gap-2 rounded-full border border-ember/50 bg-ember/10 px-5 py-2.5 text-sm text-ember transition-colors hover:bg-ember hover:text-ink"
        >
          <CloudUpload className="h-4 w-4" />
          Subir imágenes
        </button>
        <input
          ref={inputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/avif"
          multiple
          hidden
          onChange={(e) => {
            void uploadFiles(e.target.files ?? []);
            e.target.value = "";
          }}
        />
      </div>

      {/* Dropzone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        onClick={() => inputRef.current?.click()}
        className={cn(
          "mt-5 cursor-pointer rounded-3xl border-2 border-dashed px-6 py-10 text-center transition-colors",
          dragging
            ? "border-ember bg-ember/10"
            : "border-line bg-panel/30 hover:border-ember/40",
        )}
      >
        <p className="flex items-center justify-center gap-3 text-sm text-fog">
          {uploading > 0 ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin text-ember" />
              Publicando {uploading} {uploading === 1 ? "imagen…" : "imágenes…"}
            </>
          ) : (
            <>
              <CloudUpload className="h-4 w-4 text-ember" />
              Arrastra fotos aquí o haz clic para elegirlas · jpg / png / webp ·
              hasta 6 MB
            </>
          )}
        </p>
      </div>

      {/* Rejilla */}
      {loading ? (
        <div className="grid grid-cols-2 gap-4 pt-6 md:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div
              key={i}
              className="aspect-[4/3] animate-pulse rounded-2xl border border-line bg-panel/40"
            />
          ))}
        </div>
      ) : images.length === 0 ? (
        <div className="mt-6 flex flex-col items-center gap-3 rounded-3xl border border-line bg-panel/40 py-16 text-center">
          <Images className="h-6 w-6 text-fog" />
          <p className="text-sm text-fog">La galería está vacía: sube tu primera fotografía.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 pt-6 md:grid-cols-4">
          <AnimatePresence initial={false}>
            {images.map((image) => (
              <motion.figure
                key={image.path}
                layout
                initial={{ opacity: 0, scale: 0.94 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="group relative overflow-hidden rounded-2xl border border-line bg-panel/40"
              >
                <div className="aspect-[4/3] w-full overflow-hidden">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={image.path.replace(
                      "/img/products/",
                      "/media/products/",
                    )}
                    onError={(e) => {
                      // Si el alias no responde (build antiguo), vuelve a /img
                      const el = e.currentTarget;
                      if (!el.dataset.fallback) {
                        el.dataset.fallback = "1";
                        el.src = image.path;
                      }
                    }}
                    alt={image.name}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <figcaption className="flex items-center justify-between gap-2 px-3 py-2">
                  <span className="truncate font-mono text-[10px] text-fog">
                    {image.name}
                  </span>
                  <span className="shrink-0 font-mono text-[10px] text-fog/60">
                    {image.sizeKb} KB
                  </span>
                </figcaption>
                <span className="absolute left-2 top-2 rounded-full bg-ink/70 px-2 py-0.5 font-mono text-[9px] uppercase tracking-[0.2em] text-ember backdrop-blur">
                  {image.folder}
                </span>

                <div className="absolute inset-0 flex items-center justify-center gap-2 bg-ink/60 opacity-0 backdrop-blur-[2px] transition-opacity duration-300 group-hover:opacity-100">
                  <button
                    onClick={() => copyPath(image.path)}
                    aria-label={`Copiar ruta de ${image.name}`}
                    className="grid h-10 w-10 place-items-center rounded-full border border-cream/30 bg-ink/70 text-cream transition-colors hover:border-ember hover:text-ember"
                  >
                    {copied === image.path ? (
                      <Check className="h-4 w-4 text-ember" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </button>
                  {image.folder === "products" && (
                    <button
                      onClick={() => removeImage(image)}
                      disabled={deleting === image.name}
                      aria-label={`Borrar ${image.name}`}
                      className="grid h-10 w-10 place-items-center rounded-full border border-cream/30 bg-ink/70 text-cream transition-colors hover:border-red-400 hover:text-red-300 disabled:opacity-50"
                    >
                      {deleting === image.name ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Trash2 className="h-4 w-4" />
                      )}
                    </button>
                  )}
                </div>
              </motion.figure>
            ))}
          </AnimatePresence>
        </div>
      )}

      <p className="mt-5 text-xs leading-relaxed text-fog/70">
        Las imágenes subidas aterrizan en{" "}
        <code className="font-mono text-ember/80">public/img/products/</code> y
        quedan disponibles enseguida en el selector «Fotografía» del formulario
        de instrumentos. Una imagen solo se puede borrar si ningún instrumento
        la está usando.
      </p>
    </div>
  );
}
